<?php while(have_posts()): ?> <?php the_post() ?>
  <?php $__env->startSection('content'); ?>
    <section class="thf-about__content">
      <?php echo $__env->make('partials.content-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>

    <section class="thf-about__map">
      <div class="thf-about-map__container"></div>
    </section>

    <section class="thf-about__member">
      <?php the_field('about_member') ?>
    </section>
  <?php $__env->stopSection(); ?>
<?php endwhile; ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>