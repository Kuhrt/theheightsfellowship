<?php $__env->startSection('content'); ?>
  <section class="thf-home__connect">
    <div class="thf-home-connect__text">
      <?php the_field('home_connect_section') ?>
    </div>
    <div class="thf-home-connect__pages">
      <?php
        $args = array(
          'post_type' => 'connect',
          'posts_per_page' => 4
        );
        $the_query = new WP_Query( $args );
      ?>

      <?php while($the_query->have_posts()): ?> <?php $the_query->the_post() ?>
        <?php
          $thumb_id = get_post_thumbnail_id();
          $thumb_url_array = wp_get_attachment_image_src($thumb_id, 'large', true);
          $thumb_url = $thumb_url_array[0];
        ?>
        <div class="thf-home-connect-pages__page">
          <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
          <a href="<?php the_permalink(); ?>" class="thf-home-connect-pages-page__image" style="background-image:url('<?php echo $thumb_url ?>');"></a>
        </div>
      <?php endwhile; ?>
      <?php wp_reset_query() ?>
    </div>
  </section>
  <section class="thf-home__services" data-parallax="scroll" data-speed="0.9" data-image-src="<?= App\asset_path('images/sunrise.jpg'); ?>">
    <?php the_field('home_service_times') ?>
  </section>
  <?php while(have_posts()): ?> <?php the_post() ?>
    <section class="thf-home__content">
      <?php echo $__env->make('partials.content-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
  <?php endwhile; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>