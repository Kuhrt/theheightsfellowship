<article <?php post_class() ?>>
  <div class="entry-content">
    <?php the_content() ?>
  </div>
  <div class="thf-post__footer">
    <?php echo wp_link_pages(['echo' => 0, 'before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']); ?>

  </div>
  <?php comments_template('/partials/comments.blade.php') ?>
</article>
