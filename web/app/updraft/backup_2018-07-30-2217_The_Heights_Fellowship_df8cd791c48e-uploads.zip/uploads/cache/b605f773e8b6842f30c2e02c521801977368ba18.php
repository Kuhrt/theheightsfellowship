<?php if(has_post_thumbnail()): ?>
  <?php
    $thumb_id = get_post_thumbnail_id();
    $thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail-size', true);
    $thumb_url = $thumb_url_array[0];
  ?>

  <div class="thf__page-header parallax-window" data-parallax="scroll" data-speed="0.2" data-image-src="<?php echo $thumb_url ?>">
    <h1><?php echo App::title(); ?></h1>
  </div>
<?php else: ?>
  <div class="thf__page-header no-photo">
    <h1><?php echo App::title(); ?></h1>
  </div>
<?php endif; ?>
