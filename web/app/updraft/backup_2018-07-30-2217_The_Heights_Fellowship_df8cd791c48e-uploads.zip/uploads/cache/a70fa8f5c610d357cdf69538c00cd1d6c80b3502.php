<?php while(have_posts()): ?> <?php the_post() ?>
  <?php $__env->startSection('content'); ?>
    <?php
      $loop = new WP_Query( array( 'post_type' => 'staff', 'posts_per_page' => -1, 'order' => 'ASC' ) );
    ?>
    <section class="thf__staff">
      <?php while($loop->have_posts()): ?> <?php $loop->the_post() ?>
        <div class="thf-staff__member">
          <img src="<?php the_field('staff_photo'); ?>" alt="<?php the_title(); ?>" />
          <h3><a href="mailto:<?php the_field('staff_email'); ?>"><?php the_title(); ?></a></h3>
          <p><?php the_field('staff_position'); ?></p>
        </div>
      <?php endwhile; ?>
    </section>
    <?php wp_reset_query() ?>
  <?php $__env->stopSection(); ?>
<?php endwhile; ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>