jQuery(document).ready(function(){

// PrayBox Interface Show/Hide
	jQuery('input.praybox-all-checkboxes').on('click',function(){
		if(jQuery(this).is(':checked')){
			jQuery('input.praybox-id-checkbox').attr('checked',true);
		}else{
			jQuery('input.praybox-id-checkbox').attr('checked',false);
		}
	});

	jQuery('span.showhide-fields').on('click',function(){
		var fields_div_id = jQuery(this).attr('rel');
		if(jQuery(this).text()=="show"){
			jQuery(this).text("hide");
			jQuery('#'+fields_div_id).removeClass('hidden').addClass('visible');
		}else{
			jQuery(this).text("show");
			jQuery('#'+fields_div_id).removeClass('visible').addClass('hidden');
		}
	});


// PrayBox AJAX
	jQuery(document).ready(function($) {
	
		jQuery('a.praybox-remove-checked').on('click',function(){
			var req_list = jQuery.map(jQuery('input.praybox-id-checkbox:checked'), function(n,i){
				return n.value;
			}).join(',');
	
			var data = {
				action: 'pb_remove_reqs',
				req_list: req_list
			};
		
			$.post(ajaxurl, data, function(response) {
				alert(response + " requests deleted.");
				location.reload();
			});
		});
	});



});
