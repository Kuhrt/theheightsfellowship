jQuery(document).ready(function(){
//future dev

});
