<?php
/*
Plugin Name: PrayBox+
Plugin URI: http://www.praybox.com/praybox-plugin/
Description: This is a premium plugin containing advanced features that facilitates intercessory prayer by allowing visitors to post prayer requests and/or respond to prayer requests that have been posted by clicking on a button indicating that the prayer request has been prayed for. At the end of each day, visitors who have submitted prayer requests receive an email that tells them how many times they have been prayed for that day.
Version: 2.0.17
Author: Bryan Haddock
Author URI: http://www.blazingtorch.com
*/

/*  Copyright 2011  Bryan Haddock  (email : support@blazingtorch.com)

    This plugin is composed of two parts, the code that is part of WordPress
    and the code that facilitates the PrayBox+ functionality.
    
    The WordPress portion is subject to GPL license:
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
    
    The PrayBox+ portion is created by and property of Bryan Haddock and is
    licensed to individuals and organizations that purchase the right to
    use it.
*/

/* UPDATER */

define( 'PBX_STORE_URL', 'http://blazingtorch.com' );
define( 'PBX_PLUGIN_NAME', 'PrayBox Plus' );
define( 'PBX_PLUGIN_VERSION', '2.0.17' );
define( 'PBX_PLUGIN_AUTHOR', 'Bryan Haddock' );

if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	include( dirname( __FILE__ ) . '/inc/edd_functions.php' );
}

function praybox_plus_updater() {
	$license_key = trim( get_option( 'praybox_plus_license_key' ) );
	$edd_updater = new EDD_SL_Plugin_Updater( PBX_STORE_URL, __FILE__, array( 
			'version' 	=> PBX_PLUGIN_VERSION,
			'license' 	=> $license_key,
			'item_name' => PBX_PLUGIN_NAME,
			'author' 	=> PBX_PLUGIN_AUTHOR
		)
	);
}

add_action( 'admin_init', 'praybox_plus_updater' );

/* END UPDATER */

include("inc/functions.php");
include("inc/enqueue_functions.php");
include("inc/admin_pbx_ajax.php");
include("inc/public_pbx_ajax.php");

include("inc/inc_install_func.php");
include("inc/inc_pb_crons.php");
include("inc/inc_update_func.php");

register_activation_hook(__FILE__,'gd_pb_db_install');
register_activation_hook(__FILE__,'setup_pb_crons');

include("inc/inc_admin_menu_hooks.php");

//ADMIN INCLUDES
include("inc/inc_pb_settings_page.php");
include("inc/inc_pb_bannedips_page.php");
include("inc/inc_pb_request_list_pending_page.php");
include("inc/inc_pb_request_list_active_page.php");
include("inc/inc_pb_request_list_flagged_page.php");
include("inc/inc_pb_request_list_closed_page.php");
include("inc/inc_pb_request_list_archived_page.php");
include("inc/inc_pb_license_page.php");
include("inc/inc_pb_praise_report_page.php");

//SHORTCODE INCLUDES
include("inc/inc_display_pb_requests.php");
//include("inc/display_pbx_forms.php");
include("inc/inc_display_pb_compactview.php");
include("inc/inc_display_pb_expandedview.php");
include("inc/inc_display_pb_praisereports.php");

add_shortcode('pb-requests','display_pb_requests');
//add_shortcode('pbx-forms','display_pbx_forms');
add_shortcode('pb-compactview','display_pb_compactview');
add_shortcode('pb-expandedview','display_pb_expandedview');
add_shortcode('pb-praisereports','display_pb_praisereports');
add_shortcode('pb-numrequests','display_pb_numrequests');
add_shortcode('pb-numprayers','display_pb_numprayers');

//LEGACY SHORTCODE INCLUDES
include("inc/inc_display_pb_forms.php");
add_shortcode('pb-forms','display_pb_forms');


//DEACTIVATION
register_deactivation_hook(__FILE__, 'deactivate_pb_crons');
