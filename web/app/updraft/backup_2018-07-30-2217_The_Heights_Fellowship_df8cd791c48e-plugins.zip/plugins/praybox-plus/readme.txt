=== PrayBox+ ===
Contributors: Blazing Torch
Donate link: http://www.praybox.com/praybox-plugin/
Tags: church, pray, prayer, religion, ministry
Requires at least: 2.3
Tested up to: 4.0
Stable tag: 2.0.17

Prayer request application that allows users to submit requests, or pray for existing requests

== Description ==

Thank you for some generous donations that have helped us further develop this unique, important tool for Churches and organizations.  Thanks to you we have been able to fix several bugs, and add many new features for our 1.0 release.  Please help us continue to update and improve this and other ministry tools.

Prayer request application that allows users to submit requests, or pray for existing requests.  All requests can be moderated from the admin section and can be flagged by members as inappropriate requests.  There is a IP ban system in place as well to reduce inappropriate behavior.

Every time a request is prayed for, and the user clicks the "I Prayed For You" button, the requester will receive a nightly email detailing how many prayers they received that day.

= Live Praybox =
View our working version of Praybox, post a prayer request or pray for others here: [Praybox - Online Prayer Requests](http://www.praybox.com/)

= Help Develop Praybox =
Help us continue to develop Praybox and similar apps with a small donation.

= Support and Requests =
We respond to all support requests sent from our PrayBox contact form: [Contact Form](http://www.praybox.com/contact/)

== Installation ==

1. Upload 'praybox-plus' folder to the '/wp-content/plugins/' directory or use the 'Add New' option under the 'Plugins' menu in your WordPress backend and 'Upload' 'praybox-plus.zip'.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure settings for PrayBox in the WordPress dashboard by clicking on the 'PrayBox' option in your WordPress backend.
4. Enter the appropriate information into the form fields on the 'PrayBox General Settings' page.
5. Make sure the appropriate shortcodes are placed on the appropriate pages.
5. Paste shortcodes accordingly:
    * Paste this shortcode into the page you would like to use to display your listings: [pb-requests]
    * Paste this shortcode into the page you would like to use to display your submission form: [pb-forms]
    * IMPORTANT: Make sure you tell the plugin where you placed the [pb-forms] shortcode by selecting that page from the list beside "Prayer Request Form Page"
6. Have fun using this plugin and if you have any questions, requests, or positive feedback, we would love to hear from you (http://www.praybox.com/contact/)

== Screenshots ==

== Changelog ==

= July 8, 2011 - 1.0 =
* Advanced features added and released as PrayBox+

= July 14, 2011 - 1.0.1 =
* Fixed "View Details" and related links on request list page for sites not using permalinks

= August 3, 2011 - 1.0.2 =
* Fixed issue with escaped characters that was occasionally causing problems during activation.

= September 15, 2011 - 1.0.3 =
* Fixed issue with 'From' email address in emails sent by PrayBox+

= December 27, 2011 - 2.0 =
* Fixed issue regarding 'Closed' requests
* Added better permalink identification to tighten up interface
* Added additional shortcodes for displaying requests differently
* Added functionality and interface for 'Praise Reports'
* Added form validation to prayer request submission form

= December 29, 2011 - 2.0.1 =
* Changed display messages for requests that are currently pending.

= January 11, 2012 - 2.0.2 =
* Fixed issue preventing daily emails and gap alert emails from being sent.

= February 21, 2012 - 2.0.3 =
* Fixed issue regarding url characters in permalinks for editing prayer requests.
* Fixed issue with escaping characters on General Settings page.

= June 18, 2012 - 2.0.4 =
* Fixed pagination issue manifesting since WP 3.4 update (permalinks)
* Added link to Prayer Request Listings to initial and cron emails
* Added Turing Test options to General Settings Page
* Added shortcodes for displaying total number of Prayer Requests and total number of Prayers on the website

= August 10, 2012 - 2.0.5 =
* Updated escaping to protect against MySQL injection attacks.

= August 14, 2012 - 2.0.6 =
* Updated variable passing for requests to protect against potential vulnerabilities.

= January 29, 2013 - 2.0.7 =
* Bug fixes related to WP v3.5 release.
* Added scripting for automatic updates.

= February 12, 2013 - 2.0.8 =
* Fixed Pagination Issues.

= May 20, 2013 - 2.0.9 =
* Updated Admin graphic assets.

= February 3, 2014 - 2.0.10 =
* Added multi-request removal link to Active Request List admin page.
* Updated form element styles on Edit Request admin page.
* Cleaned up New Request Notification admin email

= February 21, 2014 - 2.0.11 =
* Added option to PrayBox+ General Settings page that allows administrators to disable daily emails to users.

= May 20, 2014 - 2.0.12 =
* Minor fix to plugin updater scripts.

= June 24, 2014 - 2.0.13 =
* Disabled autocapitalize and autocorrect for turing test answer field
* Added option to limit number of characters allowed in a prayer request

= July 17, 2014 - 2.0.14 =
* Corrected missing index notices appearing in WP debug mode
* Added prayer request body and link to prayer request to the "New Request Notifications" emails (formerly "Admin Notification Email")
* Added the ability to add multiple recipients to the "New Request Notifications" emails

= September 9, 2014 - 2.0.15 =
* Added special email text for when admin moderation is active, notifying requestor that the request has been submitted for moderation
* Improved interface organization and flow

= September 11, 2014 - 2.0.16 =
* Fixed issues with plugin activation and update functions

= September 20, 2014 - 2.0.17 =
* Improved compatibility with WP 4.0
