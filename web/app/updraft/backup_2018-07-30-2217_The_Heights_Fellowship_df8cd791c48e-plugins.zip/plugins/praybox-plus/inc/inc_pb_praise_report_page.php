<?php

function pb_praise_report_page() {
global $wpdb;

if(isset($_POST['action']) && $_POST['action']=="show_praise_report"){
	$req_id=$_POST['pb_request_id'];
	$wpdb->insert($wpdb->prefix.'pb_praise_reports',array('req_id'=>$req_id));	
}

if(isset($_POST['action']) && $_POST['action']=="dont_show_praise_report"){
	$req_id=$_POST['pb_request_id'];
	$wpdb->query("DELETE FROM ".$wpdb->prefix."pb_praise_reports WHERE req_id='$req_id'");
}

?>

<div class="wrap">
<div id="pbx-wrap">
<h2 class="logo-title">PrayBox+ Praise Report Management</h2>

<h3>Praise Reports</h3>

<p>To display praise reports on a page, insert the shortcode [pb-praisereports] into a page. If you would like a praise report to show on that page, click the "Show" button to the right of the prayer request you would like to display. If you would like to hide a praise report that you previously displayed, click the "Hide" button" to the right of that prayer request.</p>

<table class="pbxdata">
<tr class="headrow"><td>ID</td><td>First/Last/Email</td><td width="250">Prayer Request</td><td># Prayers</td><td>&nbsp;</td></tr>

<?php
echo getPraiseReports();
?>
</table>
</div>
</div>
<?php }