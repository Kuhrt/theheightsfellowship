<?php

function pb_request_list_archived_page() {
global $wpdb;
?>

<div class="wrap">
<div id="pbx-wrap">
<h2 class="logo-title">PrayBox+ Archived Prayer Request List</h2>

<h3>Archived Prayer Requests</h3>

<table class="pbxdata">
<tr class="headrow"><td>ID</td><td>First/Last/Email</td><td width="250">Prayer Request</td><td>IP</td><td>Posted</td><td># Prayers</td><td>&nbsp;</td></tr>

<?php
echo getRequestList('archived');
?>
</table>
</div>
</div>
<?php }