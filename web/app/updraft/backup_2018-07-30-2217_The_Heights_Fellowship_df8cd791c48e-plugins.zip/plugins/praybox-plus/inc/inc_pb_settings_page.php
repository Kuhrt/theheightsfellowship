<?php
function pb_settings_page() {

$needupdate=(get_option('pb_admin_moderation')=="")? 1 : 0;
?>

<div class="wrap">
<div id="pbx-wrap">
<h2 class="logo-title">PrayBox+ General Settings</h2>

<?php
 if( isset($_POST['update']) && $_POST['update'] == 'Y' ) {
	$kv=array();
	foreach($_POST as $key => $value){
		if($key!="update"){
		update_option($key,stripslashes($value));	
		}
	}
?>
<p><strong><?php _e('settings saved.','menu-test'); ?></strong></p>
<?php } 

 if(isset($_POST['action']) && $_POST['action']=="praybox_update"){
	updateOptionsAlpha();
?>
<p><strong><?php _e('PrayBox Plugin Options Updated. <a href="?page=pb_settings">Click here to reload the PrayBox interface.</a>','menu-test'); ?></strong></p>
<?php } else { 

if($needupdate==1){ ?>
<form method="post" class="update">
<input type="hidden" name="action" value="praybox_update" />
<p>Your PrayBox plugin has been updated and there are a few housekeeping things that need to be performed.</p>
<input type="submit" value="Update PrayBox Options" />
</form>

<?php } ?>

<p>Before using this plugin, make sure the correct information is listed in the fields below and paste the following shortcodes into the appropriate pages as indicated below:</p>

<ul style="list-style-type:disc; margin-left: 30px;">
	<li>Paste this shortcode into the page you would like to use to display your submission form: [pb-forms]</li>
	<li>Paste this shortcode into the page you would like to use to display your listings: [pb-requests]</li>
	<li>Paste this shortcode into the page you would like to use to display praise reports: [pb-praisereports]</li>
	<li>OR Paste this shortcode into the page you would like to use to display your listings (using compact view): [pb-compactview]</li>
	<li>OR Paste this shortcode into the page you would like to use to display your listings (using expanded view): [pb-expandedview]</li>
	<li>IMPORTANT: Make sure you tell the plugin where you placed the [pb-forms] shortcode by selecting that page from the list beside "Prayer Request Form Page" below</li>
	<li>If you would like to show the number of prayer requests that have been submitted, use this shortcode: [pb-numrequests]</li>
	<li>If you would like to show the number of prayers that have been lifted up on this site, use this shortcode: [pb-numprayers]</li>
</ul>

<p>Have fun using this plugin and if you have any questions, requests, or positive feedback, we would love to hear from you at <a href="http://www.blazingtorch.com/" target="_blank">www.blazingtorch.com</a></p>

<div class="postbox">
<form method="post" action="">
	<input type="hidden" name="update" value="Y" />

<h3>Mandatory Settings</h3>
	<table class="form-table">
        <tr valign="top">
        <th scope="row">Prayer Request Form Page</th>
        <td>
		   <?php
		   $pb_currently_selected_page=get_option('pb_management_page');
		   wp_dropdown_pages(array('selected'=>$pb_currently_selected_page,'name'=>'pb_management_page'));
		   ?>
		   <p>NOTE: The following shortcode MUST be pasted into the "Prayer Request Form Page" in order for people who have posted prayer requests to close their requests or submit praise reports.</p>
		   <p>[pb-forms]</p>
        </td>
        </tr>

        <tr valign="top">
        <th scope="row">Prayer Request Listings Page</th>
        <td>
		   <?php
		   $pb_currently_selected_listings_page=get_option('pb_listings_page');
		   wp_dropdown_pages(array('selected'=>$pb_currently_selected_listings_page,'name'=>'pb_listings_page'));
		   ?>
        </td>
        </tr>
	</table>

<h3>Thresholds & Limits <span class="showhide-fields" rel="thresholds-limits">show</span></h3>
<div id="thresholds-limits" class="hidden">
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Flag Threshhold</th>
        <td>
        How many times do you want a prayer request listing to be flagged before it is hidden from public?<br />
        <input type="number" name="pb_flag_threshhold" value="<?php echo get_option('pb_flag_threshhold'); ?>"/> <em>(enter '0' to disable this feature)</em>
		</td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Prayer Request Character Limit</th>
        <td>
        How many characters do you want to set as the maximum for prayer requests?<br />
        <input type="number" name="pb_limit_chars" value="<?php echo get_option('pb_limit_chars'); ?>" /> <em>(enter '0' to disable this feature)</em>
		</td>
        </tr>
    </table>
</div>

    
<h3>Text Customization <span class="showhide-fields" rel="text-customization">show</span></h3>
<div id="text-customization" class="hidden">
    <table class="form-table">        
        <tr valign="top">
        <th scope="row">Request Form Intro Text</th>
        <td>
	        This message is displayed above the form that allows people to submit their prayer requests.<br />
	        <textarea  name="pb_request_form_intro" rows="3"><?php echo get_option('pb_request_form_intro'); ?></textarea>
        </td>
        </tr>

        <tr valign="top">
        <th scope="row">Request List Intro Text</th>
        <td>
	        This message is displayed above the list of active prayer requests.<br />
	        <textarea  name="pb_request_list_intro" rows="3"><?php echo get_option('pb_request_list_intro'); ?></textarea>
        </td>
        </tr>
    </table>
</div>

<h3>Email & Notification Settings <span class="showhide-fields" rel="email-settings">show</span></h3>
<div id="email-settings" class="hidden">
	<table class="form-table">
		<tr valign="top">
        <th scope="row">Disable Daily Emails</th>
        <td>
	        Turn this option "on" if you want to DISABLE daily emails. <strong>Remember that if you disable daily emails, anyone who has posted a prayer request will not be notified when their request is prayed for.</strong><br />
	        <input type="radio" type="checkbox" <?php if(get_option('pb_daily_email_disabled')=="1"){ ?>checked="checked" <?php } ?> name="pb_daily_email_disabled" value="1" />on (disabled)<br />
	        <input type="radio" <?php if(get_option('pb_daily_email_disabled')=="0"){ ?>checked="checked" <?php } ?> name="pb_daily_email_disabled" value="0" />off (enabled)
        </td>
        </tr>

        <tr valign="top">
        <th scope="row">Daily Email Subject</th>
        <td><input type="text" name="pb_email_subject" value="<?php echo get_option('pb_email_subject'); ?>" /></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">Daily Email Reply-To Email Address</th>
        <td><input type="text" name="pb_reply_to_email" value="<?php echo get_option('pb_reply_to_email'); ?>" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Daily Email Greeting/Prefix</th>
        <td>
	        The portion of the email that precedes the information notifying the requestor how many times they have been prayed for that day.<br />
	        <textarea name="pb_email_prefix" rows="3" ><?php echo get_option('pb_email_prefix'); ?></textarea>
        </td>
        </tr>

        <tr valign="top">
        <th scope="row">Daily Email Closing/Suffix</th>
        <td>
	        The portion of the email that follows the information notifying the requestor how many times they have been prayed for that day.<br />
	        <textarea name="pb_email_suffix" rows="3" ><?php echo get_option('pb_email_suffix'); ?></textarea>
        </td>
        </tr>

        <tr valign="top">
        <th scope="row">Initial Prayer Gap</th>
        <td>
        How many hours do you want a new prayer request to sit and not be prayed for before you are notified?<br />
        <input type="number" name="pb_send_notify_hours" value="<?php echo get_option('pb_send_notify_hours'); ?>" /> <em>(enter '0' to disable this feature)</em>
		</td>
        </tr>

		<tr valign="top">
        <th scope="row">Prayer Gap Alert Email</th>
        <td><input type="text" name="pb_send_notify_email" value="<?php echo get_option('pb_send_notify_email'); ?>" /></td>
        </tr>

<?php if($needupdate==0){ ?>
		<tr valign="top">
        <th scope="row">Admin Moderation of All Requests</th>
        <td>
	        Turn this option "on" if you want to moderate all requests before they are displayed publicly.<br />
	        <input type="radio" type="checkbox" <?php if(get_option('pb_admin_moderation')=="1"){ ?>checked="checked" <?php } ?> name="pb_admin_moderation" value="1" />on<br />
	        <input type="radio" <?php if(get_option('pb_admin_moderation')=="0"){ ?>checked="checked" <?php } ?> name="pb_admin_moderation" value="0" />off
        </td>
        </tr>

		<tr valign="top">
        <th scope="row">New Request Notifications</th>
        <td>
        If you would like for an email to be sent whenever a new request is posted, put the email address to notify here<br /><textarea name="pb_admin_notify_email" rows="3" ><?php echo get_option('pb_admin_notify_email'); ?></textarea><br /><em><strong>For multiple recipients, enter the email addresses with commas separating them, like this:</strong></em><br /><code>fred@emailaddress.com,mark@emailaddress.com,suzy@suzyemail.net,nancy@another.co</code></td>
        </tr>
	</table>
</div>

<h3>Display Settings <span class="showhide-fields" rel="display-settings">show</span></h3>
<div id="display-settings" class="hidden">
	<table class="form-table">
		<tr valign="top">
        <th scope="row">Which Requests Would You Like to Display?</th>
        <td>
        <select name="pb_timeframe_display">
        <option value="0" <?php if(get_option('pb_timeframe_display')=="0"){ ?>selected="selected"<?php } ?>>all of them</option>
        <option value="30" <?php if(get_option('pb_timeframe_display')=="30"){ ?>selected="selected"<?php } ?>>only the last 30 days</option>
        <option value="60" <?php if(get_option('pb_timeframe_display')=="60"){ ?>selected="selected"<?php } ?>>only the last 60 days</option>
        <option value="90" <?php if(get_option('pb_timeframe_display')=="90"){ ?>selected="selected"<?php } ?>>only the last 90 days</option>
        <option value="120" <?php if(get_option('pb_timeframe_display')=="120"){ ?>selected="selected"<?php } ?>>only the last 120 days</option>
        </select></td>
        </tr>

		<tr valign="top">
        <th scope="row">How Many Request Would You Like to Display Per Page?</th>
        <td>
        <select name="pb_page_display">
        <option value="0" <?php if(get_option('pb_page_display')=="0"){ ?>selected="selected"<?php } ?>>all of them</option>
        <option value="5" <?php if(get_option('pb_page_display')=="5"){ ?>selected="selected"<?php } ?>>5</option>
        <option value="10" <?php if(get_option('pb_page_display')=="10"){ ?>selected="selected"<?php } ?>>10</option>
        <option value="20" <?php if(get_option('pb_page_display')=="20"){ ?>selected="selected"<?php } ?>>20</option>
        <option value="40" <?php if(get_option('pb_page_display')=="40"){ ?>selected="selected"<?php } ?>>40</option>
        <option value="60" <?php if(get_option('pb_page_display')=="60"){ ?>selected="selected"<?php } ?>>60</option>
        <option value="80" <?php if(get_option('pb_page_display')=="80"){ ?>selected="selected"<?php } ?>>80</option>
        <option value="100" <?php if(get_option('pb_page_display')=="100"){ ?>selected="selected"<?php } ?>>100</option>
        </select></td>
        </tr>
	</table>
</div>

<h3>Spam Prevention <span class="showhide-fields" rel="spam-prevention">show</span></h3>
<div id="spam-prevention" class="hidden">
	<table class="form-table">
		<tr valign="top">
        <th scope="row">Turing Test Question</th>
        <td>
        If you would like to make the request poster answer a question to prove that they are human, enter the question here:<br /><input type="text" name="pb_turing_test_question" value="<?php echo get_option('pb_turing_test_question'); ?>" /><br /><em>If no Turing Test Question is entered here, this feature is disabled.</em></td>
        </tr>

		<tr valign="top">
        <th scope="row">Turing Test Answer</th>
        <td>
        What is the correct answer to the above question:<br /><input type="text" name="pb_turing_test_answer" value="<?php echo get_option('pb_turing_test_answer'); ?>" /><br /><em>Note: For best results, change the Turing Test Question and answer every once in awhile.</em></td>
        </tr>
<?php } ?>                
    </table>
</div>
    
    <p class="submit">
    <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
    </p>

</form>
<div style="clear:both"></div></div>
<div style="clear:both"></div></div>

<p align="right">Prayer Gap emails set to run <em><?php echo wp_get_schedule('prayer_gap'); ?></em><br />
Daily Emails set to run <em><?php echo wp_get_schedule('daily_emails'); ?></em></p>

</div>
<?php }}