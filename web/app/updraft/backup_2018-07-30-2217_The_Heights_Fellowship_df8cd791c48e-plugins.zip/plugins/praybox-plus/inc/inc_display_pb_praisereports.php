<?php
function display_pb_praisereports($atts) {
	global $wpdb;
	global $post;
	
	$page_id=$post->ID;
	$permalink=get_permalink($page_id);

	$praise_report_output="<div id='praybox'>";
	
	$praise_report_output.=displayPraiseReports();
	
	$praise_report_output.="<div style='clear:both;'></div></div>";
	
	return $praise_report_output;
}
