<?php
function display_pb_expandedview($atts) {
	global $wpdb;
	global $post;
	
	$page_id=$post->ID;
	$permalink=get_permalink(get_option('pb_listings_page'));

	$request_list_output="<div id='praybox'>";

	
if(isset($_POST['action']) && $_POST['action']=="flag_this_request"){

//PRAYED FOR INSERT SCRIPT AND CONTENT
	$req_id=$_POST['pb_request_id'];
	$time_now=time();
	$ip_address=$_SERVER['REMOTE_ADDR'];
	$wpdb->insert($wpdb->prefix.'pb_flags',array('request_id'=>$req_id,'flagged_date'=>$time_now,'ip_address'=>$ip_address));

	if(isIPBanned($ip_address)=="pass"){
		//$flag_action_output.="<div class='back'><a href='$permalink'><< Back to Request List</a><div style='clear:both;'></div></div>";
		$flag_action_output.="<div class='thankyou'>Thank you for reporting inappropriate content.<div style='clear:both;'></div></div>";
		$flag_action_output.="<div style='clear:both;'></div></div>";
	}else{
		//$flag_action_output.="<div class='back'><a href='$permalink'><< Back to Request List</a><div style='clear:both;'></div></div>";
		$flag_action_output.="<div class='thankyou'>Sorry, you're not allowed to do that.<div style='clear:both;'></div></div>";
		$flag_action_output.="<div style='clear:both;'></div></div>";
	}
	
$request_list_output.=$flag_action_output;

}

if(isset($_POST['action']) && $_POST['action']=="prayed_for"){

//PRAYED FOR INSERT SCRIPT AND CONTENT
	$req_id=$_POST['pb_request_id'];
	$time_now=time();
	$ip_address=$_SERVER['REMOTE_ADDR'];
	$wpdb->insert($wpdb->prefix.'pb_prayedfor',array('request_id'=>$req_id,'prayedfor_date'=>$time_now,'ip_address'=>$ip_address));
		
	//$view_details_output.="<div class='back'><a href='$permalink'><< Back to Request List</a><div style='clear:both;'></div></div>";
	$prayed_for_output.="<div class='thankyou'>Thank you for lifting up this request in prayer.<div style='clear:both;'></div></div>";

$request_list_output.=$prayed_for_output;

}

//REQUEST LIST OUTPUT CONTENT
	if(isset($_GET['pg'])){$page=$_GET['pg'];}else{$page=1;}
	
	$request_list_output.=displayExpandedRequests($page,$permalink);
	
	$request_list_output.="<div style='clear:both;'></div></div>";
	
	return $request_list_output;

}
