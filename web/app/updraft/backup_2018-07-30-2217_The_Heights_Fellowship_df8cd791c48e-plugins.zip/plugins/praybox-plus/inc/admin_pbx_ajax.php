<?php
add_action( 'wp_ajax_pb_remove_reqs', 'pb_remove_reqs_callback' );

function pb_remove_reqs_callback() {
	global $wpdb;

	$req_list = $_POST['req_list'];
	$reqs = explode(",", $req_list);
	
	foreach($reqs as $req){
		$wpdb->delete($wpdb->prefix."pb_requests", array('ID' => $req));
	}

    echo count($reqs);

	die();
}

