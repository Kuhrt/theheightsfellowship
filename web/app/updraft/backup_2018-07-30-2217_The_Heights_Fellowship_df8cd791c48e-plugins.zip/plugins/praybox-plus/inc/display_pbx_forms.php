<?php

function display_pbx_forms($atts) {
	global $wpdb;

if(isset($_POST['action']) && $_POST['action']=="update_request"){
	//UPDATE REQUEST
	$req_id=(isset($_POST['req_id']))? $_POST['req_id'] : 0;
	$first_name=(isset($_POST['first_name']) && $_POST['first_name']!="")? clean($_POST['first_name']) : "anon";
	$last_name=(isset($_POST['last_name']) && $_POST['last_name']!="")? clean($_POST['last_name']) : "anon";
	$anon=(isset($_POST['anon']) && $_POST['anon']=='on')? 1 : 0;	
	$email=(isset($_POST['email']))? clean($_POST['email']) : "";	
	$title=(isset($_POST['title']))? clean($_POST['title']) : "";	
	$body=(isset($_POST['body']))? clean($_POST['body']) : "";	
	$notify=(isset($_POST['notify']) && $_POST['notify']=='on')? 1 : 0;
	if(isset($_POST['closed']) && $_POST['closed']=='on'){
		$closed=time();
		$active=2;
		$closed_comment=(isset($_POST['closed_comment']))? clean($_POST['closed_comment']) : "";
	$wpdb->update($wpdb->prefix.'pb_requests',array('first_name'=>$first_name,'last_name'=>$last_name,'anon'=>$anon,'email'=>$email,'closed'=>$closed,'closed_comment'=>$closed_comment,'title'=>$title,'body'=>$body,'notify'=>$notify,'active'=>$active),array('id'=>$req_id));
	}else{
		$wpdb->update($wpdb->prefix.'pb_requests',array('first_name'=>$first_name,'last_name'=>$last_name,'anon'=>$anon,'email'=>$email,'title'=>$title,'body'=>$body,'notify'=>$notify),array('id'=>$req_id));
	}
	
	$updated_request_output="";
	if(!isset($closed)){
		$updated_request_output.="<div id='praybox'>";
		$updated_request_output.="<div class='title'>Your Prayer Request Has Been Updated<div style='clear:both;'></div></div>";
		$updated_request_output.="<div class='intro'>Any changes that you have made to your prayer request have been updated.<div style='clear:both;'></div></div>";
		$updated_request_output.="<div style='clear:both;'></div></div>";	
	}else{
		$updated_request_output.="<div id='praybox'>";
		$updated_request_output.="<div class='title'>Your Prayer Request Has Been Closed<div style='clear:both;'></div></div>";
		$updated_request_output.="<div class='intro'>You will no longer have access to edit this prayer request.<div style='clear:both;'></div></div>";
		$updated_request_output.="<div style='clear:both;'></div></div>";	
	}

	return $updated_request_output;
}

if(!isset($_GET['pbid'])){

	if(isset($_POST['action']) && $_POST['action']=="submit_request"){
		//Submit Request to DB, Email Mgmt Link, and Display a Message
		$first_name=(isset($_POST['first_name']))? clean($_POST['first_name']) : "";
		$last_name=(isset($_POST['last_name']))? clean($_POST['last_name']) : "";
		$anon=(isset($_POST['anon']) && $_POST['anon']=='on')? 1 : 0;	
		$email=(isset($_POST['email']))? clean($_POST['email']) : "";	
		$authcode=rand_chars();
		$title=(isset($_POST['title']))? clean($_POST['title']) : "";	
		$body=(isset($_POST['body']))? clean($_POST['body']) : "";	
		$notify=(isset($_POST['notify']) && $_POST['notify']=='on')? 1 : 0;
		$ip_address=$_SERVER['REMOTE_ADDR'];
		$time_now=time();
		$active=(get_option('pb_admin_moderation')==1)? 0 : 1;
		$duplicate_count=duplicateCount($first_name,$last_name,$email,$title,$ip_address);
	
		$err="";
		$err.=(get_option('pb_turing_test_question')!="" && isset($_POST['turing']) && $_POST['turing']!=get_option('pb_turing_test_answer'))? "<li>Are you trying to spam this site?</li>" : "";
		$err.=(isIPBanned($ip_address)=="fail")? "<li>You are banned from using this resource.</li>" : "";
		$err.=($duplicate_count>0)? "<li>You have submitted an identical request and it is already listed.... $duplicate_count</li>" : "";
		/* $err.=($first_name=="")? "<li>You must provide your first name. Check the box if you would like to remain anonymous.</li>" : "";
		$err.=($last_name=="")? "<li>You must provide your last name. Check the box if you would like to remain anonymous.</li>" : ""; */
		/* $err.=($email=="")? "<li>Your email address cannot be blank</li>" : "";
		$err.=($title=="")? "<li>Your prayer request must have a title</li>" : ""; */
		$err.=($body=="")? "<li>Your prayer request may not be blank</li>" : "";
	
		//IF NO FLAGS, RUN IT
		if($err==""){
			$wpdb->insert($wpdb->prefix.'pb_requests',array('first_name'=>$first_name,'last_name'=>$last_name,'anon'=>$anon,'email'=>$email,'authcode'=>$authcode,'submitted'=>$time_now,'title'=>$title,'body'=>$body,'notify'=>$notify,'ip_address'=>$ip_address,'active'=>$active));
			$req_id=$wpdb->insert_id;
			$management_url=getManagementUrl($authcode);
			$site_name=get_bloginfo('name');
			
		   	$email_from=get_option('pb_reply_to_email');
		   	$email_subject="Prayer Request Posted";
			$listings_page=get_permalink(get_option('pb_listings_page'));
		   	$email_message=get_option('pb_email_prefix');
		   	
		   	
		   	if(get_option('pb_admin_moderation')=="1"){
				$email_message.="\n\nYour prayer request has been submitted and is awaiting administrator moderation.\n\n";
			}else{
				$email_message.="\n\nYour prayer request has been posted.\n\n";
			}

			if(get_option('pb_daily_email_disabled')!="1"){
				$email_message.="If you have indicated that you would like to receive notifications, you will receive an email at the end of each day that your prayer request is lifted up to the Lord letting you know how many times you were prayed for that day.\n\n";
			}
			
			$email_message.="If you would like to edit your prayer request or submit a praise report for an answered prayer, click here: $management_url\n\nIf you would like to view your prayer request along with other prayer requests that have been posted, click here: $listings_page\n\n";
	
		   	$email_message.=get_option('pb_email_suffix');
			$headers= 'Reply-To:'.$site_name.' <'.$email_from.'>'."\r\n";
			$headers.= 'From:'.$site_name.' <'.$email_from.'>'."\r\n";
		   	
		   	wp_mail($email,$email_subject,$email_message,$headers);
		   	
		   	if(get_option('pb_admin_notify_email')!=""){
		   		//send admin email
		   		$admin_notify_email=get_option('pb_admin_notify_email');
		   		$email_formatted_request="\"".stripslashes($_POST['body'])."\"";
		   		
		   		$admin_subject="A New Prayer Request Has Been Submitted";
		   		$admin_message="A new prayer request titled \"".stripslashes($title)."\" has been submitted at $site_name. This is the request that was submitted:\n\n$email_formatted_request\n\nTo view this request, click here: $listings_page?req=$req_id";
		   		
		   		if(strpos($admin_notify_email,",")!==false){
			   		$admin_notify_email_array=explode(",",$admin_notify_email);
		   		
			   		foreach($admin_notify_email_array as $admin_notify_email){
				   		wp_mail($admin_notify_email,$admin_subject,$admin_message,$headers);
			   		}
		   		}else{
		   			wp_mail($admin_notify_email,$admin_subject,$admin_message,$headers);
		   		}	
			}
			
			$submitted=1;
		}
	}else{
		$err="";
		$first_name="";
		$last_name="";
		$anon=0;
		$email="";
		$title="";
		$body="";
		$notify=0;
	}

	$output="<div id='praybox'>";

	if(isset($submitted)){
	$output.="<div class='title'>Your Prayer Request Has Been Submitted<div style='clear:both;'></div></div>";

		if(get_option('pb_daily_email_disabled')=="1"){
			$output.="<div class='intro'>You will be receiving an email shortly that contains a link that will allow you to update your prayer request. <div style='clear:both;'></div></div>";
		}else{
			$output.="<div class='intro'>You will be receiving an email shortly that contains a link that will allow you to update your prayer request. If you have indicated that you would like to be notified when you are prayed for, you will receive an email once a day letting you know how many times your prayer request has been lifted up.<div style='clear:both;'></div></div>";
		}

	}else{
		//INITIAL SUBMISSION FORM OUTPUT
		$req_limit_maxlength=(get_option('pb_limit_chars')>0)? "maxlength='".get_option('pb_limit_chars')."'" : "";
		$req_limit_span=(get_option('pb_limit_chars')>0)? "<br /><span class='limit-note'>Limit ".get_option('pb_limit_chars')."</span>" : "";
		$anon_checked=($anon==1)? "checked" : "";
		$notify_checked=($notify==1)? "checked" : "";
	
		$output.="<div class='title'><h2>".get_option('pb_request_form_intro')."</h2><div style='clear:both;'></div></div>";
		if($err!=""){
			$output.="<ul>$err</ul>";
		}
		//$output.="<p>your ip address is: ".$_SERVER['REMOTE_ADDR']."</p>";
		$output.="<form method='post'><input type='hidden' name='action' value='submit_request' />";
		$output.="<table class='subform'>";
		$output.="<tr><td class='label'>Name:</td><td class='input'><input type='text' name='first_name' value='$first_name' /></td></tr>";
		/* $output.="<tr><td class='label'>Last Name:</td><td class='input'><input type='text' name='last_name' value='$last_name' /></td></tr>"; */
		$output.="<tr><td>&nbsp;</td><td class='checkbox'><input type='checkbox' name='anon' $anon_checked /> I would like to remain anonymous. Please do not post my name.</td></tr>";
		$output.="<tr><td class='label'>Email Address:</td><td class='input'><input type='text' name='email' value='$email' /></td></tr>";
		$output.="<tr><td class='label'>Prayer Request Title:</td><td class='input'><input type='text' name='title' value='$title' /></td></tr>";
		$output.="<tr><td class='label'>Prayer Request:$req_limit_span</td><td class='input'><textarea name='body' $req_limit_maxlength >$body</textarea></td></tr>";
	
		if(get_option('pb_daily_email_disabled')!="1"){
			$output.="<tr><td class='label'>&nbsp;</td><td class='checkbox'><input type='checkbox' name='notify' $notify_checked /> I would like to be notified (once per day) when I have been prayed for.</td></tr>";
		}
	
		if(get_option('pb_turing_test_question')!=""){
			$output.="<tr><td class='label'>".get_option('pb_turing_test_question')."</td><td class='input'><input type='text' autocapitalize='off' autocorrect='off' name='turing' /></td></tr>";
		}
	
		$output.="<tr><td class='submit' colspan='2'><input type='submit' value='Submit' /></td></tr>";
		$output.="</table>";
		$output.="</form>";
	}
	
	$output.="<div style='clear:both;'></div></div>";

return $output;

}else{
	$authcode=(isset($_GET['pbid']))? $_GET['pbid'] : false;
	$mgmt_form_output="";
	if(requestStatus($authcode)=="active"){
		//IF REQUEST IS OPEN
		$req_limit_maxlength=(get_option('pb_limit_chars')>0)? "maxlength='".get_option('pb_limit_chars')."'" : "";
		$req_limit_span=(get_option('pb_limit_chars')>0)? "<br /><span class='limit-note'>Limit ".get_option('pb_limit_chars')."</span>" : "";

		$prayer_request=$wpdb->get_row("SELECT id,first_name,last_name,anon,email,title,body,notify FROM ".$wpdb->prefix."pb_requests WHERE authcode='$authcode'");
		$req_id=$prayer_request->id;
		$first_name=stripslashes($prayer_request->first_name);
		$last_name=stripslashes($prayer_request->last_name);
		if($prayer_request->anon==1){$anon="checked";}else{$anon="";}
		$email=stripslashes($prayer_request->email);
		$title=stripslashes($prayer_request->title);
		$body=prePgphOutput($prayer_request->body);
		if($prayer_request->notify==1){$notify="checked";}else{$notify="";}
		
		$mgmt_form_output.="<div id='praybox'>";
		$mgmt_form_output.="<div class='title'>Make Changes to Your Prayer Request<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<div class='intro'>Use the form below to make changes to your prayer request listing.<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<form method='post'><input type='hidden' name='action' value='update_request' /><input type='hidden' name='req_id' value='$req_id' />";
		$mgmt_form_output.="<table class='subform'>";
		$mgmt_form_output.="<tr><td class='label'>First Name:</td><td class='input'><input type='text' name='first_name' value='$first_name' /></td></tr>";
		$mgmt_form_output.="<tr><td class='label'>Last Name:</td><td class='input'><input type='text' name='last_name' value='$last_name' /></td></tr>";
		$mgmt_form_output.="<tr><td class='label'>&nbsp;</td><td class='checkbox'><input type='checkbox' name='anon' $anon /> I would like to remain anonymous. Please do not post my name.</td></tr>";
		$mgmt_form_output.="<tr><td class='label'>Email Address:</td><td class='input'><input type='text' name='email' value='$email' /></td></tr>";
		$mgmt_form_output.="<tr><td class='label'>Prayer Request Title:</td><td class='input'><input type='text' name='title' value='$title' /></td></tr>";
		$mgmt_form_output.="<tr><td class='label'>Prayer Request:$req_limit_span</td><td class='input'><textarea name='body' $req_limit_maxlength >$body</textarea></td></tr>";

		if(get_option('pb_daily_email_disabled')!="1"){
			$mgmt_form_output.="<tr><td class='label'>&nbsp;</td><td class='checkbox'><input type='checkbox' name='notify' $notify /> I would like to be notified (once per day) when I have been prayed for.</td></tr>";
		}

		$mgmt_form_output.="<tr><td colspan='2'><hr /></td></tr>";
		$mgmt_form_output.="<tr><td class='label'>&nbsp;</td><td class='checkbox'><input type='checkbox' name='closed' /> I would like to close this prayer request.</td></tr>";
		$mgmt_form_output.="<tr><td class='label'>Praise Report:</td><td class='input'><textarea name='closed_comment'></textarea></td></tr>";
		$mgmt_form_output.="<tr><td class='submit' colspan='2'><input type='submit' value='Update My Prayer Request' /></td></tr>";
		$mgmt_form_output.="</table>";
		$mgmt_form_output.="</form>";
		$mgmt_form_output.="<div style='clear:both;'></div></div>";
	}
	
	if(requestStatus($authcode)=="pending"){
		//IF REQUEST IS CLOSED
		$mgmt_form_output.="<div id='praybox'>";
		$mgmt_form_output.="<div class='title'>This Request Is Pending Review<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<div class='intro'>This prayer request cannot be edited while it is being reviewed.<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<div style='clear:both;'></div></div>";
	}

	if(requestStatus($authcode)=="closed"){
		//IF REQUEST IS CLOSED
		$mgmt_form_output.="<div id='praybox'>";
		$mgmt_form_output.="<div class='title'>This Request Has Been Closed<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<div class='intro'>Sorry, this Prayer Request has been closed and can no longer be edited.<div style='clear:both;'></div></div>";
		$mgmt_form_output.="<div style='clear:both;'></div></div>";
	}

return $mgmt_form_output;

}
}
