<?php
add_action('wp_enqueue_scripts','public_praybox_assets');
add_action('admin_enqueue_scripts', 'admin_praybox_assets');

function public_praybox_assets() {
	wp_register_style('pbx-public', plugins_url().'/praybox-plus/css/pbx-public.css');
	wp_enqueue_style('pbx-public');

	wp_enqueue_script('jquery');
	wp_enqueue_script('praybox_public', plugins_url().'/praybox-plus/js/jquery.pbx_public.js');

}

function admin_praybox_assets() {
	wp_register_style('pbx-admin', plugins_url().'/praybox-plus/css/pbx-admin.css');
	wp_enqueue_style('pbx-admin');

	wp_enqueue_script('praybox_admin', plugins_url().'/praybox-plus/js/jquery.pbx_admin.js');
}
