<?php

//ADMIN MENU INTERFACES

add_action('admin_menu','gd_pb_menu');

function gd_pb_menu() {

	$status 	= get_option( 'praybox_plus_license_status' );
	if( $status !== false && $status == 'valid' ) {
		add_menu_page('PrayBox','PrayBox+','office_admin','pb_settings','pb_settings_page',plugins_url().'/praybox-plus/images/favicon.png');
	}else{
		add_menu_page('PrayBox','PrayBox+','office_admin','praybox_plus_license','praybox_plus_license_page',plugins_url().'/praybox-plus/images/favicon.png');
	}
	

	if(get_option('pb_admin_moderation')==1){
		add_submenu_page('pb_settings','Pending Request List','Pending Request List','office_admin','pb_request_list_pending','pb_request_list_pending_page');
	}
		
	add_submenu_page('pb_settings','Active Request List','Active Request List','office_admin','pb_request_list_active','pb_request_list_active_page');
	add_submenu_page('pb_settings','Flagged Requests','Flagged Requests','office_admin','pb_request_list_flagged','pb_request_list_flagged_page');
	add_submenu_page('pb_settings','Closed Request List','Closed Request List','office_admin','pb_request_list_closed','pb_request_list_closed_page');
	add_submenu_page('pb_settings','Archived Request List','Archived Request List','office_admin','pb_request_list_archived','pb_request_list_archived_page');
	add_submenu_page('pb_settings','Praise Reports','Praise Reports','office_admin','pb_praise_reports','pb_praise_report_page');
	add_submenu_page('pb_settings','Banned IPs','Banned IPs','office_admin','pb_bannedips','pb_bannedips_page');
	add_submenu_page('pb_settings','PrayBox+ License','PrayBox+ License','office_admin','praybox_plus_license','praybox_plus_license_page');
}
