<?php
/* PLUGIN FUNCTIONS */

function clean($string){
	return strip_tags(nl2br($string),"<br>");
}

function howManyFlags($req_id){
	global $wpdb;
	$flags=$wpdb->get_results("SELECT id FROM ".$wpdb->prefix."pb_flags WHERE request_id='$req_id'");
	return $wpdb->num_rows;
}
function howManyPrayers($req_id){
	global $wpdb;
	$flags=$wpdb->get_results("SELECT id FROM ".$wpdb->prefix."pb_prayedfor WHERE request_id='$req_id'");
	return $wpdb->num_rows;
}
function isIPBanned($ip){
	global $wpdb;
	$result_array = $wpdb->get_results("SELECT id FROM ".$wpdb->prefix."pb_banned_ips WHERE ip_address='$ip'");
	$result=count($result_array);
	if($result==0){return "pass";}else{return "fail";}
}
function prePgphOutput($input){
	$reporder=array("\\r\\n","\\n","\\r");
	$badwords=array("fuck","shit","cunt","penis","bastard");

	$step1=str_replace($reporder,"||",$input);
	$step2=str_replace($badwords,"[omitted]",$step1);
	$step3=stripslashes($step2);
	$output=str_replace("||","<br />",$step3);

	return $output;
}
function requestStatus($authcode){ //returns active, pending, or closed
	global $wpdb;
	$active_status=$wpdb->get_row("SELECT active FROM ".$wpdb->prefix."pb_requests WHERE authcode='$authcode'");
	
	if($active_status){
		switch($active_status->active){
			case 0:
				$return="pending";
				break;
			case 1:
				$return="active";
				break;
			case 2:
				$return="closed";
				break;
			case 3:
				$return="archived";
				break;
		}
		return $return;
	}
}
function rand_chars() {
	for ($s = '', $i = 0, $z = strlen($a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789')-1; $i != 12; $x = rand(0,$z), $s .= $a{$x}, $i++);
	return $s;
}

function duplicateCount($fname,$lname,$email,$title,$ipaddy){
	global $wpdb;
	$duplicate_count = $wpdb->get_var("SELECT COUNT(*) FROM ".$wpdb->prefix."pb_requests WHERE first_name='$fname' AND last_name='$lname' AND email='$email' AND title='$title' AND ip_address='$ipaddy'");
	return $duplicate_count;
}

function getRequestList($status,$include_checkboxes=0){
	//THIS FUNCTION IS FOR PENDING, ACTIVE, CLOSED, OR ARCHIVED PRAYER REQUESTS
	switch($status){
		case "pending":
			$querycond="WHERE active=0 AND closed=0";
			break;
		case "active":
			$querycond="WHERE active=1";
			break;
		case "closed":
			$querycond="WHERE active=2";
			break;
		case "archived":
			$querycond="WHERE active=3";
			break;
	}
	
	global $wpdb;
	$requests=$wpdb->get_results("SELECT id,first_name,last_name,email,title,body,ip_address,submitted FROM ".$wpdb->prefix."pb_requests $querycond ORDER BY submitted DESC");
	
	$output="";
	foreach($requests as $req){
		$req_id=$req->id;
		$first_name=stripslashes($req->first_name);
		$last_name=stripslashes($req->last_name);
		$email=$req->email;
		$title=stripslashes($req->title);
		$body=prePgphOutput($req->body);
		$ip=$req->ip_address;
		$submitted=date("m-d-y",$req->submitted);
		$num_prayers=howManyPrayers($req_id);
		
		$output.="<tr class='datarow'>";
		$output.=($include_checkboxes==1)? "<td><input type='checkbox' class='praybox-id-checkbox' name='req_id' value='$req_id' /></td>" : "";
		$output.="<td>$req_id</td><td>$first_name $last_name<br />$email</td><td><strong>$title</strong><br />$body</td><td>$ip</td><td>$submitted</td><td>$num_prayers</td><td align='center'>";

		if($status=="pending"){
			$output.="<form method='post'><input type='hidden' name='action' value='approve_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Approve' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='edit_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Edit' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='remove_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Remove' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='remove_ban' /><input type='hidden' name='pb_ip_address' value='$ip' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Remove/Ban' /></form>";
		}
		if($status=="active"){
			$output.="<form method='post'><input type='hidden' name='action' value='edit_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Edit' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='remove_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Remove' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='close_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Close' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='remove_ban' /><input type='hidden' name='pb_ip_address' value='$ip' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Remove/Ban' /></form>";
		}
		if($status=="closed"){
			$output.="<form method='post'><input type='hidden' name='action' value='archive_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Archive' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='remove_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Remove' /></form>";
			$output.="<form method='post'><input type='hidden' name='action' value='reopen_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Reopen' /></form>";
		}
		
		$output.="</td></tr>";
	}
	return $output;
}

function getPraiseReports(){
	global $wpdb;
	$requests=$wpdb->get_results("SELECT id,first_name,last_name,email,closed_comment,title,body,ip_address,submitted FROM ".$wpdb->prefix."pb_requests WHERE closed_comment!='' ORDER BY submitted DESC");
	
	$output="";
	foreach($requests as $req){
		$req_id=$req->id;
		$first_name=stripslashes($req->first_name);
		$last_name=stripslashes($req->last_name);
		$email=$req->email;
		$closed_comment=prePgphOutput($req->closed_comment);
		$title=stripslashes($req->title);
		$body=prePgphOutput($req->body);
		$ip=$req->ip_address;
		$submitted=date("m-d-y",$req->submitted);
		$num_prayers=howManyPrayers($req_id);
				
		$output.="<tr class='datarow'><td>$req_id</td><td>$first_name $last_name<br />$email</td><td><strong>$title</strong><br />$body<br /><strong>Praise Report:</strong><br />$closed_comment</td><td>$num_prayers</td><td align='center'>";

		$display_array=$wpdb->get_row("SELECT req_id FROM ".$wpdb->prefix."pb_praise_reports WHERE req_id='$req_id'");
		
		if($display_array==NULL){		
			$output.="<form method='post'><input type='hidden' name='action' value='show_praise_report' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Show' /></form>";
		}else{		
			$output.="<form method='post'><input type='hidden' name='action' value='dont_show_praise_report' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' class='button-secondary' value='Hide' /></form>";
		}


		
		$output.="</td></tr>";
	}
	return $output;
}

function displayRequests($page,$permalink){
	global $wpdb;
	
	$url_pos=strpos($permalink,"?");
	if($url_pos===false){$varprefix="?";}else{$varprefix="&";}
	
	$link=$permalink.$varprefix;
	
	$flag_thresh=(!is_null(get_option('pb_flag_threshhold')))? get_option('pb_flag_threshhold') : 0;
	if(get_option('pb_timeframe_display')=="0"){$time_condition="";}else{$timeframe=strtotime("-".get_option('pb_timeframe_display')." days");$time_condition="AND submitted>$timeframe";}
	$listingsperpage=get_option('pb_page_display');
	
	$page_condition=($listingsperpage!=0)? "LIMIT ".($page-1)*$listingsperpage.",".$listingsperpage : "";
	
	$this_display_qry_from="FROM ".$wpdb->prefix."pb_requests WHERE active='1' $time_condition ORDER BY submitted DESC $page_condition";
	$total_display_qry_from="FROM ".$wpdb->prefix."pb_requests WHERE active='1' $time_condition";
	
	$active_requests=$wpdb->get_results("SELECT id,title,body,submitted $this_display_qry_from");
	$num_requests_array=$wpdb->get_results("SELECT id $this_display_qry_from");
	$num_requests=count($num_requests_array);
	$total_num_requests_array=$wpdb->get_results("SELECT id $total_display_qry_from");
	$total_num_requests=count($total_num_requests_array);
			
	$req_list_output="<div id='praybox'>";
	$req_list_output.="<div class='intro'>".get_option('pb_request_list_intro')."<div style='clear:both;'></div></div>";
	
	if($listingsperpage!=0){
		$total_pages=ceil($total_num_requests/$listingsperpage);
		if($total_pages!=1){
		$i=1;
		$req_list_output.="<div class='pagination'>Page: ";
		while($i<=$total_pages){
			if($page==$i){$linkclass=" class='active'";}else{$linkclass="";}
			$req_list_output.=" <a href='$link"."pg=$i' $linkclass>$i</a>";
		$i++;
		}
		$req_list_output.="</div>";
		}
	}
	
	$req_list_output.="<table class='praybox'>";
	$req_list_output.="<tr class='pb-titlerow'><td>Request Title</td><td># Prayers</td><td>Date</td><td>&nbsp;</td></tr>";
	
	foreach($active_requests as $a_req){
		$req_id=$a_req->id;
		$title=stripslashes($a_req->title);
		if($a_req->title!=""){$title=stripslashes($a_req->title);}else{$title="<em>Untitled</em>";}
		$body=stripslashes($a_req->body);
		$submitted=date("m-d-Y",$a_req->submitted);
		$num_prayers=howManyPrayers($req_id);
		$num_flags=howManyFlags($req_id);
		
		$flag_ratio=($flag_thresh!=0)? $num_flags/$flag_thresh : 0;
		
		if($flag_ratio<1){
		$req_list_output.="<tr class='pb-datarow'><td>$title</td><td>$num_prayers</td><td>$submitted</td><td class='input'>";
		$req_list_output.="<a href='$link"."req=$req_id'>View Details</a>";
		$req_list_output.="</td></tr>";
		}
	}
	$req_list_output.="</table>";

	if($listingsperpage!=0){
		$total_pages=ceil($total_num_requests/$listingsperpage);
		if($total_pages!=1){
		$i=1;
		$req_list_output.="<div class='pagination'>Page: ";
		while($i<=$total_pages){
			if($page==$i){$linkclass=" class='active'";}else{$linkclass="";}
			$req_list_output.=" <a href='$link"."pg=$i' $linkclass>$i</a>";
		$i++;
		}
		$req_list_output.="</div>";
		}
	}

	$req_list_output.="<div style='clear:both;'></div></div>";

	return $req_list_output;
}

function displayCompactRequests($num,$permalink,$showlink){
	global $wpdb;
	
	$url_pos=strpos($permalink,"?");
	if($url_pos===false){$varprefix="?";}else{$varprefix="&";}
	
	$link=$permalink.$varprefix;

	$flag_thresh=(!is_null(get_option('pb_flag_threshhold')))? get_option('pb_flag_threshhold') : 0;
			
	$active_requests=$wpdb->get_results("SELECT id,title,body,submitted FROM ".$wpdb->prefix."pb_requests WHERE active='1' ORDER BY submitted DESC LIMIT 0,".$num);
		
	$req_list_output="<div id='praybox'>";
	$req_list_output.="<div class='intro'>".get_option('pb_request_list_intro')."<div style='clear:both;'></div></div>";
	
	$req_list_output.="<table class='praybox'>";
	$req_list_output.="<tr class='pb-titlerow'><td>Request Title</td><td>&nbsp;</td></tr>";
	
	foreach($active_requests as $a_req){
		$req_id=$a_req->id;
		$title=stripslashes($a_req->title);
		if($a_req->title!=""){$title=stripslashes($a_req->title);}else{$title="<em>Untitled</em>";}
		$num_flags=howManyFlags($req_id);
		
		$flag_ratio=($flag_thresh!=0)? $num_flags/$flag_thresh : 0;
		
		if($flag_ratio<1){
		$req_list_output.="<tr class='pb-datarow'><td>$title</td><td class='input'><a href='$link"."req=$req_id'>View Details</a></td></tr>";
		}
	}
	$req_list_output.="</table>";
	
	if($showlink==1){
		$req_list_output.="<p align='right'><a href='$permalink'>View All Requests >></a></p>";
	}

	$req_list_output.="<div style='clear:both;'></div></div>";

	return $req_list_output;
}

function displayExpandedRequests($page,$permalink){
	global $wpdb;
	
	$url_pos=strpos($permalink,"?");
	if($url_pos===false){$varprefix="?";}else{$varprefix="&";}
	
	$link=$permalink.$varprefix;
	
	$flag_thresh=(!is_null(get_option('pb_flag_threshhold')))? get_option('pb_flag_threshhold') : 0;
	if(get_option('pb_timeframe_display')==0){$time_condition="";}else{$timeframe=strtotime("-".get_option('pb_timeframe_display')." days");$time_condition="AND submitted>$timeframe";}
	$listingsperpage=get_option('pb_page_display');
	
	$page_condition=($listingsperpage!=0)? "LIMIT ".($page-1)*$listingsperpage.",".$listingsperpage : "";
	
	$this_display_qry_from="FROM ".$wpdb->prefix."pb_requests WHERE active='1' $time_condition ORDER BY submitted DESC $page_condition";
	$total_display_qry_from="FROM ".$wpdb->prefix."pb_requests WHERE active='1' $time_condition";
	
	$active_requests=$wpdb->get_results("SELECT id,first_name,last_name,anon,title,body,submitted $this_display_qry_from");
	$num_requests_array=$wpdb->get_results("SELECT id $this_display_qry_from");
	$num_requests=count($num_requests_array);
	$total_num_requests_array=$wpdb->get_results("SELECT id $total_display_qry_from");
	$total_num_requests=count($total_num_requests_array);
		
	$req_list_output="<div class='intro'>".get_option('pb_request_list_intro')."<div style='clear:both;'></div></div>";
	
	if($listingsperpage!=0){
		$total_pages=ceil($total_num_requests/$listingsperpage);
		if($total_pages!=1){
		$i=1;
		$req_list_output.="<div class='pagination'>Page: ";
		while($i<=$total_pages){
			if($page==$i){$linkclass=" class='active'";}else{$linkclass="";}
			$req_list_output.=" <a href='$link"."pg=$i' $linkclass>$i</a>";
		$i++;
		}
		$req_list_output.="</div>";
		}
	}
	
	$req_list_output.="<table class='praybox'>";
	$req_list_output.="<tr class='pb-titlerow'><td>Request Title</td><td>Submitted By</td><td># Prayers</td><td>Date</td></tr>";
	
	foreach($active_requests as $a_req){
		$req_id=$a_req->id;
		$first_name=$a_req->first_name;
		$last_name=$a_req->last_name;
		$anon=$a_req->anon;
		$title=stripslashes($a_req->title);
		if($a_req->title!=""){$title=stripslashes($a_req->title);}else{$title="<em>Untitled</em>";}
		$body=prePgphOutput($a_req->body);
		$submitted=date("m-d-Y",$a_req->submitted);
		$num_prayers=howManyPrayers($req_id);
		$num_flags=howManyFlags($req_id);
		$display_name=($anon!=1)? $first_name." ".$last_name : "Anonymous";
		$flag_ratio=($flag_thresh!=0)? $num_flags/$flag_thresh : 0;
		
		if($flag_ratio<1){
		$req_list_output.="<tr class='pb-datarow'><td>$title</td><td>$display_name</td><td>$num_prayers</td><td>$submitted</td></tr>";
		$req_list_output.="<tr class='pb-requestrow'><td colspan='4'>$body";
		$req_list_output.="<div class='forms'>";
		$req_list_output.="<form method='post' action='$permalink'><input type='hidden' name='action' value='prayed_for' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' value='I Prayed For You' /></form>";
		$req_list_output.="<form class='flag' method='post' action='$permalink'><input type='hidden' name='action' value='flag_this_request' /><input type='hidden' name='pb_request_id' value='$req_id' /><input type='submit' value='Report Abuse' /></form>";
		$req_list_output.="<div style='clear:both;'></div></div>";
		$req_list_output.="</td></tr>";
		}
	}
	$req_list_output.="</table>";

	if($listingsperpage!=0){
		$total_pages=ceil($total_num_requests/$listingsperpage);
		if($total_pages!=1){
		$i=1;
		$req_list_output.="<div class='pagination'>Page: ";
		while($i<=$total_pages){
			if($page==$i){$linkclass=" class='active'";}else{$linkclass="";}
			$req_list_output.=" <a href='$link"."pg=$i' $linkclass>$i</a>";
		$i++;
		}
		$req_list_output.="</div>";
		}
	}


	return $req_list_output;
}

function displayPraiseReports(){
	global $wpdb;
	$flag_thresh=(!is_null(get_option('pb_flag_threshhold')))? get_option('pb_flag_threshhold') : 0;
	$praise_reports=$wpdb->get_results("SELECT req_id FROM ".$wpdb->prefix."pb_praise_reports");
	
	$praise_report_output="<table class='praybox' id='praisereports'>";
	$praise_report_output.="<tr class='pb-titlerow'><td>Prayer Request</td><td>Praise Report</td></tr>";
	
	foreach($praise_reports as $praise_report){
		$req_id=$praise_report->req_id;
	
		$a_req=$wpdb->get_row("SELECT id,first_name,last_name,anon,closed_comment,title,body,submitted FROM ".$wpdb->prefix."pb_requests WHERE id='$req_id'");	

		$req_id=$a_req->id;
		$first_name=$a_req->first_name;
		$last_name=$a_req->last_name;
		$anon=$a_req->anon;
		$closed_comment=prePgphOutput($a_req->closed_comment);
		$title=stripslashes($a_req->title);
		if($a_req->title!=""){$title=stripslashes($a_req->title);}else{$title="<em>Untitled</em>";}
		$body=prePgphOutput($a_req->body);
		$submitted=date("m-d-Y",$a_req->submitted);
		$num_prayers=howManyPrayers($req_id);
		$num_flags=howManyFlags($req_id);
		if($anon!=1){$display_name=$first_name." ".$last_name;}else{$display_name="Anonymous";}		
		$flag_ratio=($flag_thresh!=0)? $num_flags/$flag_thresh : 0;
		
		if($flag_ratio<1){
			$praise_report_output.="<tr class='pb-datarow'><td>$title</td><td>Submitted By: $display_name</td></tr>";
			$praise_report_output.="<tr class='pb-requestrow'><td>$body</td><td>$closed_comment</td></tr>";
		}
	}
	$praise_report_output.="</table>";

	return $praise_report_output;
}

function getManagementUrl($authcode){
	$management_permalink=get_permalink(get_option('pb_management_page'));
	
	$pos=strpos($management_permalink,"?");
	
	if($pos===FALSE){
		$url_char="?";
	}else{	
		$url_char="&";
	}
	
	$management_url=$management_permalink.$url_char."pbid=".$authcode;
	
	return $management_url;

}

function display_pb_numrequests(){
	global $wpdb;
	$num_requests_array=$wpdb->get_results("SELECT id FROM ".$wpdb->prefix."pb_requests");
	$request_count=count($num_requests_array);
	return $request_count;
}

function display_pb_numprayers(){
	global $wpdb;
	$prayedfor_count_array=$wpdb->get_results("SELECT id FROM ".$wpdb->prefix."pb_prayedfor");
	$prayedfor_count=count($prayedfor_count_array);
	return $prayedfor_count;
}

function praybox_plus_register_option() {
	register_setting('praybox_plus_license', 'praybox_plus_license_key', 'pb_sanitize_license' );
}
add_action('admin_init', 'praybox_plus_register_option');

function pb_sanitize_license( $new ) {
	$old = get_option( 'praybox_plus_license_key' );
	if( $old && $old != $new ) {
		delete_option( 'praybox_plus_license_status' );
	}
	return $new;
}

function praybox_plus_activate_license() {

	if( isset( $_POST['edd_license_activate'] ) ) {

	 	if( ! check_admin_referer( 'praybox_plus_nonce', 'praybox_plus_nonce' ) ) 	
			return;

		$license = trim( get_option( 'praybox_plus_license_key' ) );
			
		$api_params = array( 
			'edd_action'=> 'activate_license', 
			'license' 	=> $license, 
			'item_name' => urlencode( PBX_PLUGIN_NAME )
		);
		
		$response = wp_remote_get( add_query_arg( $api_params, PBX_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

		if ( is_wp_error( $response ) )
			return false;

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );
		
		update_option( 'praybox_plus_license_status', $license_data->license );
	}
}
add_action('admin_init', 'praybox_plus_activate_license');

function praybox_plus_deactivate_license() {

	if( isset( $_POST['edd_license_deactivate'] ) ) {

	 	if( ! check_admin_referer( 'praybox_plus_nonce', 'praybox_plus_nonce' ) ) 	
			return;

		$license = trim( get_option( 'praybox_plus_license_key' ) );
			
		$api_params = array( 
			'edd_action'=> 'deactivate_license', 
			'license' 	=> $license, 
			'item_name' => urlencode( PBX_PLUGIN_NAME )
		);
		
		$response = wp_remote_get( add_query_arg( $api_params, PBX_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

		if ( is_wp_error( $response ) )
			return false;

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );
		
		if( $license_data->license == 'deactivated' )
			delete_option( 'praybox_plus_license_status' );
	}
}
add_action('admin_init', 'praybox_plus_deactivate_license');

function praybox_plus_check_license() {

	global $wp_version;

	$license = trim( get_option( 'praybox_plus_license_key' ) );
		
	$api_params = array( 
		'edd_action' => 'check_license', 
		'license' => $license, 
		'item_name' => urlencode( PBX_PLUGIN_NAME ) 
	);

	$response = wp_remote_get( add_query_arg( $api_params, PBX_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false ) );

	if ( is_wp_error( $response ) )
		return false;

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	if( $license_data->license == 'valid' ) {
		echo 'valid'; exit;
	} else {
		echo 'invalid'; exit;
	}
}
